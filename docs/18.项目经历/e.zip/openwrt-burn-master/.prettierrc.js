module.exports = {
  singleQuote: true,
  semi: true,
  tabWidth: 2,
  useTabs: false,
  printWidth: 160,
  endOfLine: 'auto',
  bracketSpacing: true,
  jsxBracketSameLine: true,
  arrowParens: 'avoid',
  eslintIntegration: true,
  htmlWhitespaceSensitivity: 'ignore',
  'editor.codeActionsOnSave': {
    'source.fixAll.eslint': true,
  },
};
