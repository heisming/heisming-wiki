const path = require('path');
const { IgnorePlugin } = require('webpack');
const AutoImport = require('unplugin-auto-import/webpack');
const Components = require('unplugin-vue-components/webpack');
const { ElementPlusResolver } = require('unplugin-vue-components/resolvers');

function resolve(dir) {
  return path.join(__dirname, './', dir);
}

module.exports = {
  productionSourceMap: false,
  // pages: {
  //   index: {
  //     entry: 'src/main.ts',
  //     template: 'public/index.html',
  //     filename: 'index.html',
  //     title: 'vue-cli-electron',
  //     chunks: ['chunk-vendors', 'chunk-common', 'index']
  //   }
  // },
  pluginOptions: {
    plugins: [
      new IgnorePlugin({
        resourceRegExp: /serialport/,
      }),
    ],
    electronBuilder: {
      nodeIntegration: true,
      // mainProcessFile: 'src/main/index.ts',
      // rendererProcessFile: 'src/main.ts',
      // mainProcessWatch: ['src/main'],
      externals: ['serialport', 'electron'],
      builderOptions: {
        productName: '烧录工具-v${version}',
        win: {
          artifactName: '烧录工具-v${version}-${arch}.${ext}',
          icon: 'public/icons/icon.ico',
          target: ['portable'],
        },
      },
    },
  },
  configureWebpack: {
    // 路径别名配置
    resolve: {
      alias: {
        '@': resolve('src'),
      },
    },
    plugins: [
      // AutoImport({
      //   resolvers: [ElementPlusResolver()]
      // }),
      // Components({
      //   resolvers: [ElementPlusResolver()]
      // })
    ],
  },
  chainWebpack: config => {
    // 设置软件运行时标题
    config.plugin('html').tap(args => {
      args[0].title = '烧录工具';
      return args;
    });

    // svg rule loader
    const svgRule = config.module.rule('svg'); // 找到svg-loader
    svgRule.uses.clear(); // 清除已有的loader, 如果不这样做会添加在此loader之后
    svgRule.exclude.add(/node_modules/); // 正则匹配排除node_modules目录
    svgRule.exclude.add(/iconfont/); // 正则匹配排除iconfont目录
    svgRule // 添加svg新的loader处理
      .test(/\.svg$/)
      .use('svg-sprite-loader')
      .loader('svg-sprite-loader')
      .options({
        symbolId: 'icon-[name]',
      });

    // 修改images loader 添加svg处理
    const imagesRule = config.module.rule('images');
    imagesRule.exclude.add(resolve('src/assets/svg'));
    config.module.rule('images').test(/\.(png|jpe?g|gif|svg)(\?.*)?$/);
  },
  css: {
    loaderOptions: {
      scss: {
        prependData: '@import "@/styles/mixin.scss";',
      },
    },
  },
};
