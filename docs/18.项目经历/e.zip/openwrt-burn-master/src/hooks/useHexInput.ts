import { onMounted, Ref, ref } from 'vue';

export function useHexInput(el: HTMLInputElement): { isHex: Ref<boolean>; inputValue: Ref<string> } {
  const isHex = ref(false);
  const inputValue = ref('');
  onMounted(() => {
    el.onkeydown = onKeydown;
  });
  return {
    isHex,
    inputValue
  };
}

const hexRegexp = /[0-9a-fA-F ]/;

const onKeydown = (e: KeyboardEvent) => {
  if (!e.key.match(hexRegexp)) {
    e.preventDefault();
  }
};
