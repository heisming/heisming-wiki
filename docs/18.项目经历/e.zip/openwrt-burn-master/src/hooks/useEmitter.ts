import mitt from 'mitt';

export const useEmitter = () => {
  const emitter = mitt<{ [key: string]: any }>();
  return emitter;
};
