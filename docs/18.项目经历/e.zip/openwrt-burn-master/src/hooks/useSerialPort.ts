import { sendAsync } from '@/utils/ipcHelper';
import { PortInfo } from '@serialport/bindings-cpp';
import { ipcRenderer } from 'electron';
import { SerialPort } from 'serialport';
import { reactive, ref } from 'vue';
import { errorBox } from '@/utils/message';
import { IpcRendererEvent } from 'electron/main';
import MessageUtil from '@/utils/messageUtil';

interface SerialPortOpenOptions {
  path: string;
  baudRate: number;
  dataBits: number;
  stopBits: number;
  parity: string;
}

const list = ref<(PortInfo & { friendlyName: string })[]>([]);

const serialPort = reactive({
  isOpen: false,
  path: '',
  baudRate: 115200,
  dataBits: 8,
  stopBits: 1,
  parity: 'none',
  write: async (data: string | Buffer) => {
    if (!serialPort.isOpen) throw new Error('请先打开串口');
    if (!data) throw new Error('请输入发送内容');
    await sendAsync('writeData', data);
  },
  writeSync: async (data: string | Buffer) => {
    if (!serialPort.isOpen) throw new Error('请先打开串口');
    if (!data) throw new Error('请输入发送内容');
    const res = await sendAsync<Buffer>('writeSync', data);
    return res;
  },
  close: async () => {
    await sendAsync('closeSerialPort');
    // serialPort.isOpen = false;
    // ipcRenderer.off('dataReceived', onDataReceived);
  },
  dataReceived: (data: Buffer): any => data,
});

const search = async () => {
  try {
    // eslint-disable-next-line no-spaced-func
    const { port, list: serialPortList } = await sendAsync<{ port: SerialPort; list: (PortInfo & { friendlyName: string })[] }>('searchSerialPort');

    if (port) {
      serialPort.baudRate = port.baudRate;
      serialPort.path = port.path;
      serialPort.isOpen = port.isOpen;
    }
    list.value = serialPortList;
  } catch (error) {
    console.error(error);
  }
};

const open = async (options: SerialPortOpenOptions) => {
  try {
    await sendAsync('openSerialPort', options);
    serialPort.baudRate = options.baudRate;
    serialPort.path = options.path;
    serialPort.isOpen = true;
    serialPort.dataBits = options.dataBits;
    serialPort.stopBits = options.stopBits;
    serialPort.parity = options.parity;
    ipcRenderer.on('dataReceived', onDataReceived);
    ipcRenderer.on('portClose', () => {
      serialPort.isOpen = false;
      ipcRenderer.off('dataReceived', onDataReceived);
    });
  } catch (error) {
    MessageUtil.error(error);
  }
};

const onDataReceived = (event: IpcRendererEvent, data: Buffer) => serialPort.dataReceived(data);

export function useSerialPort() {
  // search();
  return {
    serialPort,
    list,
    search,
    open,
  };
}
