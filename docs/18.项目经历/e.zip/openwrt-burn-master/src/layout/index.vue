<template>
  <div class="app-container aside-collapse">
    <aside class="aside-container">
      <Sidebar />
    </aside>
    <main class="main-container">
      <header class="header-container">
        <!-- <NavBar /> -->
        <AppBar />
      </header>
      <router-view v-slot="{ Component, route }">
        <!-- <transition name="fade-transform" mode="out-in"> -->
        <keep-alive>
          <component :is="Component" :key="route.fullPath" />
        </keep-alive>
        <!-- </transition> -->
      </router-view>
    </main>
  </div>
</template>

<script lang="ts" setup>
import AppBar from '@/components/AppBar.vue';
import Sidebar from './sidebar/index.vue';
import NavBar from './navBar/index.vue';
</script>

<style lang="scss" scoped>
@import '@/styles/variables.scss';
@import '@/styles/transition.scss';
.app-container {
  position: relative;
  width: 100%;
  height: 100%;
  .aside-container {
    height: 100vh;
    position: fixed;
    width: $sidebarWidth;
    overflow-x: hidden;
    background: $menuBg;
    transition: width 0.28s;
  }

  .main-container {
    margin-left: $sidebarWidth;
    transition: margin-left 0.28s;
    position: relative;
    overflow: hidden;
    padding: 10px;
  }

  .header-container {
    height: 32px;
    // border-bottom: 1px solid #e9ecf7;
    position: relative;
    margin-left: -10px;
  }

  &.aside-collapse {
    .aside-container {
      width: 64px;
    }
    .main-container {
      margin-left: 64px;
    }
  }
  &.aside-hidden {
  }
  &.aside-show {
  }
}
</style>
