<template>
  <nav class="nav-bar">
    <Hamburger />
    <Breadcrumb />
    <div class="toolbar"></div>
  </nav>
</template>

<script setup lang="ts">
// import { useUserStore } from '@/store/user';
import Hamburger from './Hamburger.vue';
import Breadcrumb from './Breadcrumb.vue';

// const userStore = useUserStore();
</script>

<style lang="scss" scoped>
.nav-bar {
  display: flex;
  // position: fixed;
  height: 60px;
  width: 100%;
  box-sizing: border-box;
  background-color: #fff;
  z-index: 10;
  .toolbar {
    margin-left: auto;
    margin-right: 20px;
    @include flex(row, center, center);
    &_item {
      @include hoverEffect;
      height: 100%;
      padding: 0 10px;
      @include flex(row, center, center);
    }
    .factory_info {
      padding-right: 10px;
    }
  }
}
</style>
