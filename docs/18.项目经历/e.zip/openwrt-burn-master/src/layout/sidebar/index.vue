<template>
  <Logo />
  <el-scrollbar class="sidebar-body">
    <el-menu
      :background-color="sidebarVariables.menuBg"
      :default-active="activeMenu"
      class="sidebar-menu"
      :text-color="sidebarVariables.menuText"
      :unique-opened="false"
      :active-text-color="sidebarVariables.menuActiveText"
      collapse
      :collapse-transition="false"
    >
      <Item v-for="route in menuRoutes" :key="route.path" :item="route" :base-path="route.path" />
    </el-menu>
    <div class="blank"></div>
    <!-- <transition name="fade">
      <div v-if="!app.asideCollapse" class="info-container">
        <div class="info-box">{{ version }}</div>
        <div class="info-box">构建于：{{ buildAt }}</div>
      </div>
    </transition> -->
  </el-scrollbar>
</template>

<script lang="ts" setup>
import { computed } from 'vue';
import { useRoute } from 'vue-router';
import sidebarVariables from '@/styles/variables.scss';
import menuRoutes from '@/router/routes/menu';
import Item from './Item.vue';
import Logo from './Logo.vue';

// const version = process.env.VITE_VERSION ? 'v' + process.env.VITE_VERSION : 'develop';
// const [buildAtDate, buildAtTime] = ((process.env.VITE_VERSION_TIME || process.env.VITE_UPDATED_AT) as string).split(' ');
// const buildAt = buildAtDate + ' ' + buildAtTime;

// const menu = computed(() => {
//   const [home, serialPort, ...rest] = menuRoutes;
//   if (app.connectType === 'serialPort') return [serialPort, ...rest];
//   return [home, ...rest];
// });
const title = '配置工具';
const activeMenu = computed(() => {
  const route = useRoute();
  const { meta, path } = route;
  if (meta.activeMenu) {
    return meta.activeMenu;
  }

  return path;
});
</script>

<style lang="scss" scoped>
@import '@/styles/variables.scss';
.sidebar-header {
  height: 60px;
  background: #394167;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-weight: bold;
  .header-icon {
    font-size: 20px;
  }
  .header-title {
    margin-left: 10px;
  }
}

.sidebar-body {
  height: calc(100vh - 60px);
}

.sidebar-menu {
  border-right: none;
  text-align: left;
}

.blank {
  height: 117px;
}
.info-container {
  position: fixed;
  bottom: 0;
  width: $sidebarWidth;
  font-size: 14px;
  background-color: #304156;
  padding-bottom: 20px;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.info-box {
  color: #fff;
  margin-bottom: 5px;
}

.fade-enter-active {
  transition: opacity 0.28s;
  transition-delay: 0.28s;
}
.fade-leave-active {
  transition: none;
}

.fade-enter,
.fade-leave-active {
  opacity: 0;
}
</style>
