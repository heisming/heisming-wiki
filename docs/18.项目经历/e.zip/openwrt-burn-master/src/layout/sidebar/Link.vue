<template>
  <component :is="type" v-bind="linkProps(to)">
    <slot></slot>
  </component>
</template>

<script lang="ts" setup>
import { computed } from 'vue';

const props = defineProps({
  to: {
    type: String,
    required: true,
  },
});

const type = computed(() => {
  if (isExternal(props.to)) {
    return 'a';
  }
  return 'router-link';
});

const isExternal = (path: string): boolean => {
  return /^(https?:|mailto:|tel:)/.test(path);
};

const linkProps = (to: string) => {
  if (isExternal(props.to)) {
    return {
      href: to,
      target: '_blank',
      rel: 'noopener',
    };
  }
  return {
    to,
  };
};
</script>

<style lang="scss" scoped>
a:focus,
a:active {
  outline: none;
}

a,
a:focus,
a:hover {
  cursor: pointer;
  color: inherit;
  text-decoration: none;
}
</style>
