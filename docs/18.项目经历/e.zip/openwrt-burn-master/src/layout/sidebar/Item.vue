<template>
  <div v-if="!item.meta || !item.meta.hidden">
    <template v-if="!alwaysShowRootMenu && theOnlyOneChild && !theOnlyOneChild.children">
      <AppLink v-if="theOnlyOneChild.meta" :to="resolvePath(theOnlyOneChild)">
        <el-menu-item :index="resolvePath(theOnlyOneChild)" :class="{ 'sub-menu-title-no-dropdown': isFirstLevel }">
          <svg-icon :name="theOnlyOneChild.meta?.icon" class="menu-svg-icon" />
          <template #title>
            <span>{{ theOnlyOneChild.meta?.title }}</span>
          </template>
        </el-menu-item>
      </AppLink>
    </template>
    <el-sub-menu v-else :index="resolvePath(item)" popper-append-to-body>
      <!-- popper-append-to-body -->
      <template #title>
        <svg-icon :name="item.meta?.icon" class="menu-svg-icon" />
        <span>{{ item.meta?.title }}</span>
      </template>
      <Item v-for="child in item.children" :key="child.path" :item="child" :is-first-level="false" :base-path="resolvePath(child)" />
    </el-sub-menu>
  </div>
</template>

<script lang="ts">
import path from 'path-browserify';
import { computed, defineComponent, PropType } from 'vue';
import { RouteRecordRaw } from 'vue-router';
import AppLink from './Link.vue';

export default defineComponent({
  name: 'SidebarItem',
  components: {
    AppLink,
  },
  props: {
    item: {
      type: Object as PropType<RouteRecordRaw>,
      required: true,
    },
    isFirstLevel: {
      type: Boolean,
    },
    basePath: {
      type: String,
      required: true,
    },
  },
  setup(props) {
    const alwaysShowRootMenu = computed(() => {
      if (props.item.meta && props.item.meta.alwaysShow) {
        return true;
      }
      return false;
    });

    const showingChildNumber = computed(() => {
      if (props.item.children) {
        const showingChildren = props.item.children.filter(item => {
          if (item.meta && item.meta.hidden) {
            return false;
          }
          return true;
        });
        return showingChildren.length;
      }
      return 0;
    });

    const theOnlyOneChild = computed(() => {
      if (showingChildNumber.value > 1) {
        return null;
      }
      if (props.item.children) {
        for (const child of props.item.children) {
          if (!child.meta || !child.meta.hidden) {
            return child;
          }
        }
      }

      return { ...props.item, path: '' };
    });

    const isExternal = (pagePath: string): boolean => {
      return /^(https?:|mailto:|tel:)/.test(pagePath);
    };

    const resolvePath = (route: RouteRecordRaw) => {
      if (isExternal(route.path)) {
        return route.path;
      }
      if (route.meta?.newTabShow) {
        return window.location.origin + props.basePath + route.path;
      }
      if (isExternal(props.basePath)) {
        return props.basePath;
      }
      return path.resolve(props.basePath as string, route.path);
    };

    return {
      alwaysShowRootMenu,
      showingChildNumber,
      theOnlyOneChild,
      resolvePath,
      isExternal,
    };
  },
});
</script>

<style lang="scss" scoped>
@import '@/styles/variables.scss';

.el-menu-item,
.el-sub-menu {
  // padding: 0 !important;
  :deep(.el-sub-menu__title) {
    padding-left: 20px !important;
  }
  :deep(div) {
    padding: 0 !important;
    position: relative;
    svg {
      vertical-align: middle !important;
    }
  }
  .el-menu-item {
    background-color: $subMenuBg;
  }
  &:hover {
    background-color: $menuHover;
  }
}

.menu-svg-icon {
  font-size: 24px;
  margin-right: 10px;
  margin-left: 0;
}

.el-sub-menu {
  :deep(.el-sub-menu__title:hover) {
    background-color: $menuHover !important;
  }
}

.el-menu--collapse {
  .el-sub-menu {
    :deep(.el-sub-menu__title) {
      padding-left: 0 !important;
      .el-sub-menu__icon-arrow {
        display: none;
      }
      span {
        height: 0;
        width: 0;
        overflow: hidden;
        visibility: hidden;
        display: inline-block;
      }
    }
  }
  .menu-svg-icon {
    margin-right: 0;
    margin-left: 20px;
  }
}
</style>
