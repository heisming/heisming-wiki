/** 波特率 */
export const BaudRateList = [1200, 2400, 4800, 9600, 19200, 38400, 43000, 56000, 57600, 115200, 230400, 460800, 921600];

/** 数据位 */
export const DataBitList = [5, 6, 7, 8];

/** 停止位 */
export const StopBitList = [1, 1.5, 2];

/** 校验位 */
export enum Parity {
  none,
  odd,
  even,
  mark,
  space,
}
