<template>
  <div class="hex-input">
    <el-input ref="inputRef" :model-value="modelValue" :placeholder="placeholder" @keydown="onKeyDown" @input="onInput" />
    <el-checkbox :model-value="isHex" class="hex-input_check" @change="onHexChange">hex</el-checkbox>
  </div>
</template>

<script lang="ts" setup>
import { decode, encode } from 'iconv-lite';
import { ref, toRefs } from 'vue';

const props = defineProps({
  modelValue: {
    type: String,
    default: '',
  },
  isHex: {
    type: Boolean,
    default: false,
  },
  placeholder: {
    type: String,
    default: '',
  },
});
const { modelValue, isHex } = toRefs(props);
const emit = defineEmits(['update:modelValue', 'update:isHex']);
const inputRef = ref<HTMLInputElement>();

const onKeyDown = (e: KeyboardEvent) => {
  if (isHex.value) {
    if (!e.key.match(/[0-9a-fA-F ]/)) {
      e.preventDefault();
    }
  }
};

const onInput = (input: string) => {
  if (isHex.value) {
    emit('update:modelValue', input.replaceAll(/[^0-9a-fA-F ]/g, ''));
  } else {
    emit('update:modelValue', input);
  }
};

const strToHex = (hex: string) => {
  const buffer = encode(hex, 'gb2312');
  const array: string[] = [];
  buffer.forEach(item => {
    array.push(item.toString(16).padStart(2, '0'));
  });
  return array.join(' ');
};

const hexToStr = (str: string) => {
  return decode(
    Buffer.from(
      str
        .replaceAll(' ', '')
        .match(/(\d|[a-f]|[A-F]){2}/g)!
        .map(item => parseInt(item, 16))
    ),
    'gb2312'
  );
};

const onHexChange = (status: boolean) => {
  emit('update:isHex', status);
  if (!modelValue.value) return;
  if (isHex.value) {
    emit('update:modelValue', hexToStr(modelValue.value));
  } else {
    emit('update:modelValue', strToHex(modelValue.value));
  }
};
</script>

<style lang="scss" scoped>
.hex-input {
  &_check {
    margin-left: 10px;
  }
}
</style>
