<template>
  <svg :class="svgClass" :style="style">
    <use :xlink:href="iconName" />
  </svg>
</template>

<script lang="ts">
import { computed } from 'vue';
import { defineComponent } from 'vue';
export default defineComponent({
  props: {
    name: {
      type: String,
      required: false
    },
    style: {
      type: Object,
      required: false
    }
  },
  setup(props) {
    const iconName = computed(() => `#icon-${props.name}`);
    const svgClass = computed(() => {
      if (props.name) {
        return `svg-icon icon-${props.name}`;
      }
      return 'svg-icon';
    });
    return {
      svgClass,
      iconName
    };
  }
});
</script>

<style>
.svg-icon {
  fill: currentColor;
  vertical-align: middle;
  width: 1em;
  height: 1em;
}
</style>
