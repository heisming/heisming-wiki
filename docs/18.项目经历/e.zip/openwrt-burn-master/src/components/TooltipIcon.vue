<template>
  <el-tooltip :content="tooltip">
    <template #content>
      <slot name="tooltip"></slot>
    </template>
    <el-icon class="tooltip-icon"><question-filled /></el-icon>
  </el-tooltip>
</template>

<script lang="ts" setup>
import { QuestionFilled } from '@element-plus/icons-vue';

defineProps({
  tooltip: {
    type: String,
    default: ''
  }
});
</script>

<style lang="scss" scoped>
.tooltip-icon {
  display: inline;
  vertical-align: middle;
  margin-left: 2px;
  color: #909399;
}
</style>
