<template>
  <div id="app-bar">
    <!-- <div id="app-icon">
      <img src="@/assets/logo.png" />
    </div> -->
    <div id="app-title">烧录工具 {{ version }}</div>
    <div id="app-action">
      <div class="app-action-button" @click="setWin('min')">
        <svg-icon name="app-hidden" />
      </div>
      <div class="app-action-button" @click="setWin('max')">
        <svg-icon name="app-fullsize" />
      </div>
      <div class="app-action-button button-red" @click="setWin('close')">
        <svg-icon name="app-exit" />
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ipcRenderer } from 'electron';
import { ElMessage } from 'element-plus';
import { h, ref } from 'vue';
import { confirmBox } from '@/utils/message';
import version from '@/version';

// const win = remote.getCurrentWindow();

// const originSize = ref(true);

// const autoMaximize = () => {
//   originSize.value ? win.maximize() : win.restore();
//   originSize.value = !originSize.value;
// };

const setWin = (cmd: string) => {
  ipcRenderer.send(cmd);
};
const closeConfirm = () => {
  confirmBox('', {
    confirmFunc: () => {
      setWin('close');
    },
    cancelFunc: () => {
      setWin('hide');
    },
    cancelButtonText: '最小化到托盘',
    confirmButtonText: '关闭',
    title: '是否确认关闭',
  });
};
</script>

<style lang="scss" scoped>
@import '@/styles/variables.scss';
#app-bar {
  background-color: #263238;
  background-color: $headerBg;
  color: #000;
  color: $headerText;
  display: flex;
  // 如果你想让某区域可以拖动，将其设为drag
  // 但是设为drag的区域无法被点击，请注意
  // 可以设置为no-drag来恢复点击
  // If you want to make a region draggable, set it to drag
  // But the area set as drag cannot be clicked, please note
  // can be set to no-drag to resume clicks
  -webkit-app-region: drag;
  height: 32px;
  position: fixed;
  top: 0;
  width: calc(100% - 64px);
  z-index: 9999;
}

#app-icon {
  padding: 16px 20px;
  img {
    width: 20px;
    height: 20px;
  }
}

#app-title {
  flex: 1;
  padding: 7px 15px;
  font-size: 12px;
  line-height: 18px;
}

#app-action {
  padding: 0;
  font-size: 16px;
  display: flex;
  -webkit-app-region: no-drag;
  text-align: center;
}

.app-action-button {
  padding: 0 8px;
  color: #fff;
  transition: 0.2s ease;
  opacity: 0.7;
  line-height: 32px;
}

.app-action-button:hover {
  background-color: #436677;
  opacity: 1;
}

.app-action-button:active {
  background-color: #3a4a52;
}

.button-red:hover {
  background-color: red;
}

.button-red:active {
  background-color: #c11818;
}
</style>
