<template>
  <div>
    <div class="search-form">
      <el-form inline>
        <el-form-item>
          <el-select v-model="port" :disabled="serialPort.isOpen" @visible-change="onVisibleChange">
            <el-option v-for="item in list" :key="item.path" :label="item.friendlyName" :value="item.path" />
          </el-select>
        </el-form-item>
        <!-- <el-form-item class="search-form_baud-rate">
          <el-select v-model="baudRate" :disabled="serialPort.isOpen">
            <el-option v-for="option in BaudRateList" :key="option" :value="option" />
          </el-select>
        </el-form-item>
        <el-form-item class="search-form_data-bits">
          <el-select v-model="dataBits" :disabled="serialPort.isOpen">
            <el-option v-for="option in DataBitList" :key="option" :value="option" />
          </el-select>
        </el-form-item>
        <el-form-item class="search-form_stop-bits">
          <el-select v-model="stopBits" :disabled="serialPort.isOpen">
            <el-option v-for="option in StopBitList" :key="option" :value="option" />
          </el-select>
        </el-form-item>
        <el-form-item class="search-form_parity">
          <el-select v-model="parity" :disabled="serialPort.isOpen">
            <el-option v-for="option in parityOptions" :key="option" :value="option" :label="option" />
          </el-select>
        </el-form-item> -->
        <el-form-item>
          <el-button v-if="!serialPort.isOpen" type="primary" @click="openSerialPort">打开串口</el-button>
          <el-button v-else type="primary" @click="closeSerialPort">关闭串口</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 输入输出 -->
    <div class="data-box">
      <el-scrollbar>
        <!-- <div class="data-box_buttons"> -->
        <!-- <el-button @click="searchDevice" type="primary">搜索设备</el-button>
          <el-button @click="readParam" type="primary">读取工作参数</el-button>
          <el-button @click="writeWorkParam" type="primary">配置工作参数</el-button>
          <el-button type="primary" @click="exportParam">导出模板</el-button>
          <el-button type="primary" @click="importParam">导入模板</el-button>
          <el-button type="primary" @click="sendCmd('default_work_params')">恢复默认参数</el-button>
          <el-button type="primary" @click="sendCmd('reboot')">重启设备</el-button>
          <el-button type="primary" @click="sendCmd('ota')">立即升级</el-button> -->

        <!-- <el-button type="primary" >恢复出厂参数</el-button> -->
        <!-- <el-button type="primary" @click="writeCmd('rrpc,getimei')">查询IMEI号</el-button>
          <el-button type="primary" @click="writeCmd('rrpc,getcsq')">查询信号强度</el-button>
          <el-button type="primary" @click="writeCmd('rrpc,getver')">查询固件版本</el-button>
          <el-button type="primary" @click="writeCmd('rrpc,geticcid')">查询ICCID号</el-button>
          <el-button type="primary" @click="writeCmd('rrpc,getproject')">查询项目名称</el-button>
          <el-button type="primary" @click="writeCmd('rrpc,getvbatt')">查询VBATT电压</el-button> -->
        <!-- <el-button type="primary" @click="sendCmd('get_netmode')">获取network</el-button>
          <el-button type="primary" @click="sendCmd('get_csq')">获取csq</el-button>
          <el-button type="primary" @click="sendCmd('get_imei')">获取imei</el-button>
          <el-button type="primary" @click="sendCmd('get_iccid')">获取iccid</el-button>
          <el-button type="primary" @click="sendCmd('get_muid')">获取muid</el-button>
          <el-button type="primary" @click="sendCmd('get_vbatt')">获取vbatt</el-button> -->
        <!-- </div> -->
        <div class="data-box_output">
          <el-input ref="outputRef" v-model="output" type="textarea" readonly rows="15" placeholder="输出区" />
        </div>
        <div class="data-box_bottom">
          <el-checkbox v-model="hexReceive" class="data-box_hex">HEX</el-checkbox>
          RX:{{ RX }}
          <el-button
            class="data-box_clear"
            @click="
              TX = 0;
              RX = 0;
            "
          >
            重置计数
          </el-button>
          <el-button @click="output = ''">清除输出</el-button>
        </div>
        <div class="data-box_input">
          <el-input v-model="input" type="textarea" rows="2" placeholder="输入区" @keydown="onKeyDown" @input="onInput" />
        </div>
        <div class="data-box_bottom">
          <el-checkbox v-model="hexSend" class="data-box_hex" @change="onHexSendChange">HEX</el-checkbox>
          TX:{{ TX }}
          <el-button class="data-box_clear" @click="input = ''">清除发送</el-button>
          <el-button type="primary" @click="sendInput">发送</el-button>
        </div>
      </el-scrollbar>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { useSerialPort } from '@/hooks/useSerialPort';
import { nextTick, onMounted, ref } from 'vue';
import { BaudRateList, DataBitList, StopBitList, Parity } from '@/constants/serialport';
import dayjs from 'dayjs';
import { decode, encode } from 'iconv-lite';
import MessageUtil from '@/utils/messageUtil';

const port = ref('');
const baudRate = ref(57600);
const dataBits = ref(8);
const stopBits = ref(1);
const parity = ref('none');
const input = ref('');
const output = ref('');
const outputRef = ref();

const { serialPort, list, open, search } = useSerialPort();
const parityOptions = Object.keys(Parity).filter(key => Number(key));

const paramRef = ref();

const hexSend = ref(false);
const hexReceive = ref(false);

const RX = ref(0);
const TX = ref(0);

const isJson = (str: any) => {
  if (typeof str === 'string') {
    try {
      JSON.parse(str);
      return true;
    } catch (e) {
      return false;
    }
  } else return false;
};

const onKeyDown = (e: KeyboardEvent) => {
  if (hexSend.value) {
    if (!e.key.match(/[0-9a-fA-F ]/)) {
      e.preventDefault();
    }
  }
};

const onInput = (str: string) => {
  if (hexSend.value) {
    input.value = str.replaceAll(/[^0-9a-fA-F ]/g, '');
  }
};

const outputLog = (data: string, receive = false) => {
  const sendData = encode(data, 'gb2312');
  output.value += `[${receive ? 'RX<-' : 'TX->'}] ${dayjs(new Date()).format('HH:mm:ss')}\n`;
  output.value += data;
  output.value += '\n\n';
  TX.value += sendData.length;
  outputScrollToBottom();
};

// 自动滚屏
const outputScrollToBottom = () => {
  const textarea = outputRef.value.$el.children[0];
  nextTick(() => {
    textarea.scrollTop = textarea.scrollHeight;
  });
};

// 获取串口
const searchSerialPort = async () => {
  await search();
  if (serialPort.path) port.value = serialPort.path;

  if (!serialPort.path && list.value.length) {
    port.value = list.value[0].path;
  }
};

// 打开串口
const openSerialPort = async () => {
  await open({ path: port.value, baudRate: baudRate.value, dataBits: dataBits.value, stopBits: stopBits.value, parity: parity.value });
  serialPort.dataReceived = (data: Buffer) => {
    output.value += `[RX<-] ${dayjs(new Date()).format('HH:mm:ss')}\n`;
    output.value += hexReceive.value ? bufferToHex(data) : decode(data, 'gb2312');
    output.value += '\n\n';
    RX.value += data.length;
    outputScrollToBottom();
    if (decode(data, 'gb2312').includes('Please choose the operation:')) {
      send(encode('2', 'gb2312'));
    }
    if (decode(data, 'gb2312').includes('Are you sure?(Y/N)')) {
      send(encode('y', 'gb2312'));
    }
    if (decode(data, 'gb2312').includes('Input device IP')) {
      send(Buffer.from('\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b192.168.1.1\n'));
    }
    if (decode(data, 'gb2312').includes('Input server IP')) {
      send(Buffer.from('\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b192.168.1.95\n'));
    }
    if (decode(data, 'gb2312').includes('Input Linux Kernel filename')) {
      send(Buffer.from('d007.bin\n'));
    }
    // if (decode(data, 'gb2312').includes('NetBootFileXferSize')) {
    // }
  };
};

const send = (data: any) => {
  serialPort
    .write(data)
    .then(res => {
      output.value += `[TX->] ${dayjs(new Date()).format('HH:mm:ss')}\n`;
      output.value += data;
      output.value += '\n\n';
      TX.value += data.length;
      outputScrollToBottom();
    })
    .catch(error => MessageUtil.error(error));
};

// 关闭串口
const closeSerialPort = async () => {
  await serialPort.close();
};

// 选项下拉时重新搜索串口
const onVisibleChange = (visible: boolean) => {
  if (visible) {
    searchSerialPort();
  }
};

// 下发输入
const sendInput = () => {
  if (!input.value) return MessageUtil.error('请先输入内容');
  /* eslint-disable @typescript-eslint/indent */
  const sendData = hexSend.value
    ? Buffer.from(
        input.value
          .replaceAll(' ', '')
          .match(/(\d|[a-f]|[A-F]){2}/g)!
          .map(item => parseInt(item, 16))
      )
    : encode(input.value, 'gb2312');
  /* eslint-enable @typescript-eslint/indent */
  serialPort
    .write(sendData)
    .then(res => {
      output.value += `[TX->] ${dayjs(new Date()).format('HH:mm:ss')}\n`;
      output.value += input.value;
      output.value += '\n\n';
      TX.value += sendData.length;
      outputScrollToBottom();
    })
    .catch(error => MessageUtil.error(error));
};

// 下发指令
const sendCmd = async (cmd: string) => {
  try {
    if (!serialPort.isOpen) return MessageUtil.error('请先打开串口');
    const cmdData = JSON.stringify({ cmd });
    outputLog(cmdData);
    await serialPort.write(cmdData);
  } catch (error) {
    MessageUtil.error(error);
  }
};

const hexToStr = (hex: string) => {
  const buffer = encode(hex, 'gb2312');
  const array: string[] = [];
  buffer.forEach(item => {
    array.push(item.toString(16).padStart(2, '0'));
  });
  return array.join(' ');
};

const strToHex = (str: string) => {
  return decode(
    Buffer.from(
      str
        .replaceAll(' ', '')
        .match(/(\d|[a-f]|[A-F]){2}/g)!
        .map(item => parseInt(item, 16))
    ),
    'gb2312'
  );
};

const bufferToHex = (buffer: Buffer) => {
  const array: string[] = [];
  buffer.forEach(item => {
    array.push(item.toString(16).padStart(2, '0'));
  });
  return array.join(' ');
};

const onHexSendChange = () => {
  if (!input.value) return;
  if (hexSend.value) {
    input.value = hexToStr(input.value);
  } else {
    input.value = strToHex(input.value);
  }
};

onMounted(() => {
  searchSerialPort();
});
</script>

<style lang="scss" scoped>
.data-box {
  &_bottom {
    margin-top: 20px;
  }
  &_input {
    margin-top: 20px;
  }
}
</style>
