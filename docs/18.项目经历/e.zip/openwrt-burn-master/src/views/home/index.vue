<template>
  <div>
    <h3>连接方式</h3>
    <div class="select-box">
      <el-card class="select-box__item" @click="configBySerialPort">烧录</el-card>
      <el-card class="select-box__item" @click="configByUdp">测试</el-card>
    </div>
  </div>
</template>

<script lang="ts" setup>
import MessageUtil from '@/utils/messageUtil';
import { useRouter } from 'vue-router';

const router = useRouter();

const configBySerialPort = () => {
  // router.replace('/config/serialPort');
};

const configByUdp = () => {
  // MessageUtil.warning('开发中...');
};
</script>

<style lang="scss" scoped>
.select-box {
  min-height: calc(100vh - 200px);
  @include flex(row, space-around, center);
  &__item {
    @include flex(row, center, center);
    width: 200px;
    height: 200px;
    cursor: pointer;
  }
}
</style>
