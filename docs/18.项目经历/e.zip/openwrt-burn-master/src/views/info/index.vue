<template>
  <h3>公司信息</h3>
</template>

<script lang="ts" setup></script>

<style lang="scss" scoped></style>
