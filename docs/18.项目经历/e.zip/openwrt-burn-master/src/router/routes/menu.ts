import { RouteRecordRaw } from 'vue-router';

const menuRoutes: RouteRecordRaw[] = [
  // {
  //   path: '/home',
  //   name: 'Home',
  //   meta: { title: '配置', icon: 'ito' },
  //   component: () => import('@/views/home/index.vue'),
  // },
  {
    path: '/burn',
    name: 'Burn',
    meta: { title: '配置', icon: 'ito' },
    component: () => import('@/views/burn/index.vue'),
  },
  {
    path: '/info',
    name: 'Info',
    meta: { title: '公司信息', icon: 'question' },
    component: () => import('@/views/info/index.vue'),
  },
];

export default menuRoutes;
