import { app, BrowserWindow, ipcMain } from 'electron';

export const setBrowserWindowEvent = (window: BrowserWindow): void => {
  ipcMain.on('min', () => window.minimize());
  ipcMain.on('max', () => {
    if (window.isMaximized()) {
      window.restore();
    } else {
      window.maximize();
    }
  });
  ipcMain.on('close', () => {
    window.close();
  });
  ipcMain.on('hide', () => window.hide());
};
