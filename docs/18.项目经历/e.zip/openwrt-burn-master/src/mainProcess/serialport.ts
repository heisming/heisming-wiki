import { app, BrowserWindow, ipcMain } from 'electron';
import { SerialPort, SerialPortOpenOptions } from 'serialport';
import { PortInfo, AutoDetectTypes } from '@serialport/bindings-cpp';
import { InterByteTimeoutParser } from '@serialport/parser-inter-byte-timeout';
import { IpcMainEvent } from 'electron/main';
import { decode, encode } from 'iconv-lite';

let serialPortList: PortInfo[] = [];
let port: SerialPort | null = null;
let parser: InterByteTimeoutParser | null;

const getSerialPortList = async () => {
  return await SerialPort.list();
};

const openSerialPort = (event: IpcMainEvent, options: SerialPortOpenOptions<AutoDetectTypes>) => {
  const { path, baudRate, dataBits, stopBits, parity } = options;
  port = new SerialPort({ path, baudRate, dataBits, stopBits, parity }, err => event.sender.send('openSerialPort', { result: !err, msg: err }));
  // event.sender.send('openSerialPort', { result: true, data: true });
  const dataReceived = (data: any) => {
    onDataReceived(event, data);
  };
  parser = port.pipe(new InterByteTimeoutParser({ interval: 100 }));
  parser.on('data', dataReceived);
  port.on('close', () => {
    port && port.off('data', dataReceived);
    event.sender.send('portClose');
  });
};

const closeSerialPort = (event: IpcMainEvent) => {
  port &&
    port.close(error => {
      if (!error) {
        port = null;
        parser = null;
      }
      event.sender.send('closeSerialPort', { result: !error, msg: error });
    });
};

const searchSerialPort = async (event: IpcMainEvent) => {
  try {
    serialPortList = await SerialPort.list();
    event.sender.send('searchSerialPort', {
      result: true,
      data: { port: port ? { isOpen: port.isOpen, baudRate: port.baudRate, path: port.path } : null, list: serialPortList }
    });
  } catch (error) {
    event.sender.send('searchSerialPort', { result: false, msg: error });
  }
};

const writeData = (event: IpcMainEvent, data: string) => {
  port &&
    port.write(data, error => {
      event.sender.send('writeData', { result: !error, msg: error });
    });
};

// 下发数据后等待响应
const writeSync = (event: IpcMainEvent, data: string) => {
  if (port) {
    port.write(data, error => {
      if (error) {
        return event.sender.send('writeSync', { result: !error, msg: error });
      }
      parser &&
        parser.once('data', res => {
          event.sender.send('writeSync', { result: true, data: res });
        });
      setTimeout(() => event.sender.send('writeSync', { result: false, msg: '响应超时' }), 1000);
    });
  }
};

const onDataReceived = (event: IpcMainEvent, data: Buffer) => {
  event.sender.send('dataReceived', data);
};

export const setSerialportEvent = async (window: BrowserWindow): Promise<void> => {
  serialPortList = await SerialPort.list();

  ipcMain.on('searchSerialPort', searchSerialPort);

  ipcMain.on('openSerialPort', openSerialPort);

  ipcMain.on('closeSerialPort', closeSerialPort);

  ipcMain.on('writeData', writeData);

  ipcMain.on('writeSync', writeSync);
};
