import { BrowserWindow, dialog, ipcMain, SaveDialogOptions, OpenDialogOptions } from 'electron';
import fs from 'fs';

/**
 * 保存文件对话框
 * @param win 窗口
 * @param data 数据
 * @param options 对话框选项
 */
async function saveDialog(win: BrowserWindow, data: any, options: SaveDialogOptions) {
  try {
    const { filePath, canceled } = await dialog.showSaveDialog(win, options);
    win.webContents.send('saveDialog', { result: true, data: { filePath, canceled } });

    if (filePath) fs.writeFileSync(filePath, data, 'utf-8');
  } catch (error) {
    win.webContents.send('saveDialog', { result: false, msg: error });
  }
}

/**
 * 打开文件对话框
 * @param win 窗口
 * @param options 对话框选项
 */
async function openDialog(win: BrowserWindow, options: OpenDialogOptions) {
  try {
    const { canceled, filePaths } = await dialog.showOpenDialog(win, options);
    if (!filePaths[0]) {
      return win.webContents.send('openDialog', { result: true, data: { canceled } });
    }
    const data = fs.readFileSync(filePaths[0], 'utf-8');
    win.webContents.send('openDialog', { result: true, data: { data, canceled } });
  } catch (error) {
    win.webContents.send('saveDialog', { result: false, msg: error });
  }
}

// 监听对话框事件
export function setDialog(win: BrowserWindow): void {
  ipcMain.on('saveDialog', (event, data: any, options: SaveDialogOptions) => {
    saveDialog(win, data, options);
  });

  ipcMain.on('openDialog', (event, options: OpenDialogOptions) => {
    openDialog(win, options);
  });
}
