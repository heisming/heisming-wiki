import { Tray, Menu, app, BrowserWindow, nativeImage } from 'electron';
const isMac = process.platform === 'darwin';
let tray = null;

export const setTray = (win: BrowserWindow): void => {
  const image = nativeImage.createFromPath('public/icons/icon.png');

  tray = new Tray(image);

  let contextMenu = Menu.buildFromTemplate([
    {
      label: '显示',
      role: 'zoom'
    },
    {
      label: '退出',
      role: 'quit'
    }
  ]);
  if (!isMac) {
    tray.on('click', () => {
      winShow(win);
    });
  }
  tray.setToolTip('配置工具');
  tray.setContextMenu(contextMenu);
};

const winShow = (win: BrowserWindow): void => {
  if (win.isVisible()) {
    if (win.isMinimized()) {
      win.restore();
      win.focus();
    } else {
      win.focus();
    }
  } else {
    !isMac && win.minimize();
    win.show();
    win.setSkipTaskbar(false);
  }
};
