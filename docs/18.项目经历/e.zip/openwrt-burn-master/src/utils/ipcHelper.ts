import { ipcRenderer } from 'electron';
import { IpcRendererEvent } from 'electron/main';

/**
 * 渲染进程与主进程通信异步处理
 * @param channel 频道，发送与接收一致
 * @param args 携带参数
 * @returns
 */
export const sendAsync = <T = any>(channel: string, ...args: any[]): Promise<T> => {
  return new Promise((resolve, reject) => {
    ipcRenderer.once(channel, (event: IpcRendererEvent, { result, msg, data }: { result: boolean; msg?: string | Error; data: T }) => {
      if (result) resolve(data);
      else reject(msg);
    });
    ipcRenderer.send(channel, ...args);
  });
};
