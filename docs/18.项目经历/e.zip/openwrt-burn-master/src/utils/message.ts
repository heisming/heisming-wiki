import { Action, ElMessage, ElMessageBox, MessageBoxState, ElMessageBoxOptions } from 'element-plus';
import 'element-plus/theme-chalk/el-message.css';
import 'element-plus/theme-chalk/el-message-box.css';

type MessageType = '' | 'success' | 'warning' | 'info' | 'error';

interface ConfirmBoxOptions {
  confirmFunc: () => void;
  cancelFunc: () => void;
}

export function confirmBox(message: string, options: Partial<ConfirmBoxOptions & ElMessageBoxOptions>): void {
  const { confirmFunc, cancelFunc, beforeClose, type, closeOnClickModal, confirmButtonText, cancelButtonText, title } = options;

  ElMessageBox.confirm(message, '提示', {
    type,
    closeOnClickModal: closeOnClickModal ?? false,
    confirmButtonText: confirmButtonText ?? '确认',
    cancelButtonText: cancelButtonText ?? '取消',
    title,
    beforeClose:
      beforeClose ??
      (async (action: Action, instance: MessageBoxState, done: () => void) => {
        try {
          if (action === 'confirm') {
            instance.confirmButtonLoading = true;
            await confirmFunc?.();
          }
        } catch (error) {
          ElMessage.error(error as string);
        }
        instance.confirmButtonLoading = false;
        done();
      }),
  }).catch(e => {
    if (cancelFunc) cancelFunc();
    else ElMessage.info('已取消');
  });
}

export function errorBox(error: unknown): void {
  ElMessage.error({
    /* eslint-disable */
    message:
      error instanceof Error
        ? error.message
        : typeof error === 'string' || error instanceof String
        ? `${error}`
        : JSON.stringify(error) === '{}'
        ? (error as Error).toString()
        : JSON.stringify(error),
    /* eslint-disable */
    duration: 2000,
    grouping: true,
    showClose: true,
  });
}
