import MessageUtil from '@/utils/messageUtil';
import { App } from 'vue';

/** 错误捕获 */
export const setupErrorHandler = (app: App) => {
  /** 组件渲染方法和侦听器执行期间抛出的未捕获错误 */
  app.config.errorHandler = (err: any, instance, info) => {
    console.error(err, instance, info);
    MessageUtil.error(err);
  };

  /** 捕获与 vue 无关 JS 错误 */
  window.onerror = event => {
    console.error(event);
    // MessageUtil.error(event as string);
  };

  /** 捕获所有未处理异步错误 */
  window.addEventListener('unhandledrejection', event => {
    event.preventDefault();
    MessageUtil.error(event.reason);
    console.error(event.reason);
  });
};
