import { NotificationParamsTyped, ElMessageBox, MessageBoxState, Action, ElMessageBoxOptions, ElNotification } from 'element-plus';

/** 确认框选项 */
interface ConfirmBoxOptions extends ElMessageBoxOptions {
  /** 标题 */
  title?: string;
  /** 取消回调 */
  cancel?: () => void;
  /** 确认回调 */
  confirm?: (() => Promise<void>) | (() => void);
}

/** 弹窗提示工具方法 */
export default class MessageUtil {
  static defaultMessageOption = { duration: 1500, offset: 50 };

  /**
   * 成功提示
   * @param options 提示选项
   * @returns
   */
  static success(options?: NotificationParamsTyped) {
    return ElNotification.success({ ...this.defaultMessageOption, ...(typeof options === 'string' ? { message: options } : { ...options }) });
  }

  /**
   * 信息提示
   * @param options 提示选项
   * @returns
   */
  static info(options?: NotificationParamsTyped) {
    return ElNotification.info({ ...this.defaultMessageOption, ...(typeof options === 'string' ? { message: options } : { ...options }) });
  }

  /**
   * 警告提示
   * @param options 提示选项
   * @returns
   */
  static warning(options?: NotificationParamsTyped) {
    return ElNotification.warning({ ...this.defaultMessageOption, ...(typeof options === 'string' ? { message: options } : { ...options }) });
  }

  /**
   * 错误提示
   * @param options 提示选项
   * @returns
   */
  static error(options?: NotificationParamsTyped | Error | unknown) {
    if (typeof options === 'string') {
      return ElNotification.error({ ...this.defaultMessageOption, message: options });
    }
    if (options instanceof Error) {
      return ElNotification.error({ ...this.defaultMessageOption, message: options.message });
    }
    return ElNotification.error({ ...this.defaultMessageOption, ...(options as object) });
  }

  /**
   * 确认提示
   * @param message 确认框提示文字
   * @param options 确认框选项
   */
  static async confirmBox(message: string, options: ConfirmBoxOptions) {
    const { title, confirm, cancel, ...rest } = options;
    const confirmOptions: ElMessageBoxOptions = {
      closeOnClickModal: false,
      type: 'warning',
      beforeClose: async (action: Action, instance: MessageBoxState, done: () => void) => {
        try {
          if (action === 'confirm') {
            instance.confirmButtonLoading = true;
            await confirm?.();
          }
        } catch (error: any) {
          this.error(error);
        }
        instance.confirmButtonLoading = false;
        done();
      },
      ...rest,
    };
    try {
      await ElMessageBox.confirm(message, title || '提示', confirmOptions);
    } catch {
      if (cancel) cancel();
      else this.info('已取消');
    }
  }
}
