export class RegularUtil {
  /**
   * 检测是否为空对象
   * @param obj 目标对象
   * @returns
   */
  static isEmptyObject(obj: any): boolean {
    return JSON.stringify(obj) === '{}';
  }

  /**
   * 检测是否为空
   * @param target
   */
  static isEmpty(target: any): boolean {
    return (!target && target !== 0) || (this.isArray(target) && !target.length) || (this.isPlainObject(target) && !Object.keys(target).length);
  }

  static isArray(arr: any): boolean {
    return Array.isArray(arr);
  }

  static isPlainObject(value: any): boolean {
    return Object.prototype.toString.call(value) === '[object Object]';
  }

  /**
   * 检测是否为json字符串
   * @param str json字符串
   * @returns
   */
  static isJSON(str: string): boolean {
    if (typeof str == 'string') {
      try {
        JSON.parse(str);
        return true;
      } catch (e) {
        return false;
      }
    } else return false;
  }
}
