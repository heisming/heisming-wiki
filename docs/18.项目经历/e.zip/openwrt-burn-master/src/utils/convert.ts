export class ConvertUtil {
  static pick(obj: any, arr: string[]): any {
    return arr.reduce((acc, curr) => {
      curr in obj && (acc[curr] = obj[curr]);
      return acc;
    }, {} as any);
  }
  static strToHex = (str: string) => {
    if (!str) return '';
    let result = [];
    let hexStr = '';
    for (let i = 0, j = str.length; i < j; i++) {
      let code = str.charCodeAt(i);
      if (code <= 0x7f) {
        result.push(code);
      } else if (code <= 0x7ff) {
        result.push(0xc0 | (0x1f & (code >> 6)));
        result.push(0x80 | (0x3f & code));
      } else if (code <= 0xffff) {
        result.push(0xe0 | (0x0f & (code >> 12)));
        result.push(0x80 | (0x3f & (code >> 6)));
        result.push(0x80 | (0x3f & code));
      } else {
        return '';
      }
    }
    Uint8Array.from(result).forEach(item => {
      const hex = item.toString(16);
      hexStr += hex.length % 2 ? '0' + hex : hex;
    });
    return hexStr;
  };

  static hexToStr = (hex: string) => {
    let array = Uint8Array.from(
      hex
        .split(/(\w{2})/)
        .filter(item => item)
        .map(item => parseInt(item, 16))
    );
    let result = '';
    for (let i = 0, j = array.length; i < j; i++) {
      let code = array[i];
      if (code >= 0 && code <= 0x7f) {
        code = 0x7f & code;
      } else if (code <= 0xdf) {
        code = ((0x1f & array[i]) << 6) | (0x3f & array[i + 1]);
        i += 1;
      } else if (code <= 0xef) {
        code = ((0x0f & array[i]) << 12) | ((0x3f & array[i + 1]) << 6) | (0x3f & array[i + 2]);
        i += 2;
      } else {
        return '';
      }
      let char = String.fromCharCode(code);
      result += char;
    }
    return result;
  };
}
