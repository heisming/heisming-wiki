import 'vue-router';

declare module 'vue-router' {
  interface RouteMeta {
    title?: string;
    icon?: string;
    hidden?: boolean;
    guards?: string[];
    roles?: string[];
    breadcrumb?: boolean;
    activeMenu?: string;
    alwaysShow?: boolean;
    newTabShow?: boolean;
  }
}
