import { createApp } from 'vue';
import { createPinia } from 'pinia';
import ElementPlus from 'element-plus';
import 'element-plus/theme-chalk/index.css';
import zhCn from 'element-plus/es/locale/lang/zh-cn';
import { setupErrorHandler } from '@/utils/errrorHandler';

// 引入svg组件
import SvgIcon from '@/components/SvgIcon.vue';
import App from './App.vue';
import router from './router';

import '@/styles/index.scss';
import 'normalize.css';

const requireAll = (requireContext: __WebpackModuleApi.RequireContext) => requireContext.keys().map(requireContext);
const req = require.context('@/assets/svg', false, /\.svg$/);
requireAll(req);

const app = createApp(App);
app.use(router);
app.use(createPinia());
app.use(ElementPlus, { locale: zhCn });
setupErrorHandler(app);
// app.use(ElLoading);
// app.directive('loading', ElLoading.directive);

app.component('SvgIcon', SvgIcon);
app.mount('#app');
